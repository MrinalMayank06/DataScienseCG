from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np

# Load model
model = joblib.load("model.pkl")

# Create FastAPI app
app = FastAPI(
    title="ML Deployment API",
    description="FastAPI + Docker ML Deployment Project",
    version="1.0"
)

# Input schema
class IrisFeatures(BaseModel):
    features: list[float]

# Home route
@app.get("/")
def home():
    return {
        "message": "🚀 FastAPI ML Deployment Running Successfully"
    }

# Prediction route
@app.post("/predict")
def predict(data: IrisFeatures):

    features = np.array(data.features).reshape(1, -1)

    prediction = model.predict(features)

    return {
        "prediction": int(prediction[0])
    }
