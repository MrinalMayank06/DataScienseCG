# 🚀 FastAPI + Docker ML Deployment

## Step 1 — Install Dependencies

```bash
pip install -r requirements.txt
```

---

## Step 2 — Train Model

```bash
cd app
python train_model.py
```

---

## Step 3 — Run FastAPI Locally

```bash
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000/docs
```

---

## Step 4 — Build Docker Image

Go to project root folder:

```bash
docker build -t ml-fastapi-app .
```

---

## Step 5 — Run Docker Container

```bash
docker run -p 8000:8000 ml-fastapi-app
```

---

## Test API

POST Request:

```json
{
  "features": [5.1, 3.5, 1.4, 0.2]
}
```
